'use strict';


function Appointment(startTime, endTime) {
  this._startTime = startTime;
  this._endTime = endTime;  
};


Appointment.prototype.clashesWith = function(otherAppointment) {
  // write your clash detection code here

  
};
module.exports = Appointment;
